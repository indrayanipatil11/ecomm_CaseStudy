package dao;

import entity.*;
import exception.*;
import util.DBConnUtil;
import util.DBPropertyUtil;
import java.sql.*;
import java.util.*;



public class OrderProcessorRepositoryImpl implements OrderProcessorRepository {
    private Connection connection;

    public OrderProcessorRepositoryImpl() {
        try {
            String connectionString = DBPropertyUtil.getConnectionUrl();
            this.connection = DBConnUtil.establishConnection(connectionString);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Connection getConnection() {
        return this.connection;
    }

    // Customer Management
    @Override
    public boolean createCustomer(Customer customer) throws SQLException {

        String query = "INSERT INTO customers (name, email, password) VALUES ( ?, ?,?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            //stmt.setInt (1,customer.getCustomerId());
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getEmail());
            stmt.setString(3, customer.getPassword());
            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteCustomer(int customerId) throws SQLException, CustomerNotFoundException {
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }
        
        String query = "DELETE FROM customers WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            return stmt.executeUpdate() > 0;
        }
    }

    // Product Management
    @Override
    public boolean createProduct(Product product) throws SQLException {
        String query = "INSERT INTO products (name, price, description, stockQuantity) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, product.getName());
            stmt.setDouble(2, product.getPrice());
            stmt.setString(3, product.getDescription());
            stmt.setInt(4, product.getStockQuantity());
            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteProduct(int productId) throws SQLException, ProductNotFoundException {
        if (!productExists(productId)) {
            throw new ProductNotFoundException("Product with ID " + productId + " not found.");
        }
        
        String query = "DELETE FROM products WHERE product_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, productId);
            return stmt.executeUpdate() > 0;
        }
    }

    // Cart Management
    @Override
    public boolean addToCart(Customer customer, Product product, int quantity) 
            throws SQLException, CustomerNotFoundException, ProductNotFoundException {
        if (!customerExists(customer.getCustomerId())) {
            throw new CustomerNotFoundException("Customer with ID " + customer.getCustomerId() + " not found.");
        }
        if (!productExists(product.getProductId())) {
            throw new ProductNotFoundException("Product with ID " + product.getProductId() + " not found.");
        }
        
        String query = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, customer.getCustomerId());
            stmt.setInt(2, product.getProductId());
            stmt.setInt(3, quantity);
            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean removeFromCart(Customer customer, Product product) 
            throws SQLException, CustomerNotFoundException, ProductNotFoundException {
        if (!customerExists(customer.getCustomerId())) {
            throw new CustomerNotFoundException("Customer with ID " + customer.getCustomerId() + " not found.");
        }
        if (!productExists(product.getProductId())) {
            throw new ProductNotFoundException("Product with ID " + product.getProductId() + " not found.");
        }
        
        String query = "DELETE FROM cart WHERE customer_id = ? AND product_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, customer.getCustomerId());
            stmt.setInt(2, product.getProductId());
            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public List<Product> getAllFromCart(Customer customer) throws SQLException, CustomerNotFoundException {
        if (!customerExists(customer.getCustomerId())) {
            throw new CustomerNotFoundException("Customer with ID " + customer.getCustomerId() + " not found.");
        }
        
        List<Product> products = new ArrayList<>();
        String query = "SELECT p.* FROM products p JOIN cart c ON p.product_id = c.product_id WHERE c.customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, customer.getCustomerId());
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Product product = new Product(
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getString("description"),
                    rs.getInt("stockQuantity")
                );
                products.add(product);
            }
        }
        return products;
    }

    // Order Management
    @Override
    public boolean placeOrder(Customer customer, List<Map<Product, Integer>> productsWithQuantities, String shippingAddress) 
            throws SQLException, CustomerNotFoundException, ProductNotFoundException {
        
        if (!customerExists(customer.getCustomerId())) {
            throw new CustomerNotFoundException("Customer with ID " + customer.getCustomerId() + " not found.");
        }
        
        // Calculate total price and validate products/stock
        double totalPrice = 0;
        for (Map<Product, Integer> map : productsWithQuantities) {
            for (Map.Entry<Product, Integer> entry : map.entrySet()) {
                Product product = entry.getKey();
                int quantity = entry.getValue();
                
                if (!productExists(product.getProductId())) {
                    throw new ProductNotFoundException("Product with ID " + product.getProductId() + " not found.");
                }
                
                if (getProductStock(product.getProductId()) < quantity) {
                    throw new ProductNotFoundException("Insufficient stock for product ID " + product.getProductId());
                }
                
                totalPrice += product.getPrice() * quantity;
            }
        }
        
        // Start transaction
        connection.setAutoCommit(false);
        
        try {
            // 1. Create order
            String orderQuery = "INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES (?, NOW(), ?, ?)";
            int orderId;
            
            try (PreparedStatement stmt = connection.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, customer.getCustomerId());
                stmt.setDouble(2, totalPrice);
                stmt.setString(3, shippingAddress);
                stmt.executeUpdate();
                
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    orderId = rs.getInt(1);
                } else {
                    throw new SQLException("Failed to get order ID.");
                }
            }
            
            // 2. Create order items and update stock
            String itemQuery = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";
            String updateStockQuery = "UPDATE products SET stockQuantity = stockQuantity - ? WHERE product_id = ?";
            
            try (PreparedStatement itemStmt = connection.prepareStatement(itemQuery);
                 PreparedStatement stockStmt = connection.prepareStatement(updateStockQuery)) {
                
                for (Map<Product, Integer> map : productsWithQuantities) {
                    for (Map.Entry<Product, Integer> entry : map.entrySet()) {
                        Product product = entry.getKey();
                        int quantity = entry.getValue();
                        
                        // Add order item
                        itemStmt.setInt(1, orderId);
                        itemStmt.setInt(2, product.getProductId());
                        itemStmt.setInt(3, quantity);
                        itemStmt.addBatch();
                        
                        // Update stock
                        stockStmt.setInt(1, quantity);
                        stockStmt.setInt(2, product.getProductId());
                        stockStmt.addBatch();
                    }
                }
                
                itemStmt.executeBatch();
                stockStmt.executeBatch();
            }
            
            // 3. Clear cart
            String clearCartQuery = "DELETE FROM cart WHERE customer_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(clearCartQuery)) {
                stmt.setInt(1, customer.getCustomerId());
                stmt.executeUpdate();
            }
            
            connection.commit();
            return true;
            
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    @Override
    public List<Map<Product, Integer>> getOrdersByCustomer(int customerId) 
            throws SQLException, CustomerNotFoundException, OrderNotFoundException {
        
        if (!customerExists(customerId)) {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");
        }
        
        // Get all order IDs for the customer
        String orderQuery = "SELECT order_id FROM orders WHERE customer_id = ?";
        List<Integer> orderIds = new ArrayList<>();
        
        try (PreparedStatement stmt = connection.prepareStatement(orderQuery)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                orderIds.add(rs.getInt("order_id"));
            }
        }
        
        if (orderIds.isEmpty()) {
            throw new OrderNotFoundException("No orders found for customer ID " + customerId);
        }
        
        // Get items for each order
        List<Map<Product, Integer>> orders = new ArrayList<>();
        String itemQuery = "SELECT p.*, oi.quantity FROM order_items oi " +
                          "JOIN products p ON oi.product_id = p.product_id " +
                          "WHERE oi.order_id = ?";
        
        for (int orderId : orderIds) {
            Map<Product, Integer> orderDetails = new HashMap<>();
            
            try (PreparedStatement stmt = connection.prepareStatement(itemQuery)) {
                stmt.setInt(1, orderId);
                ResultSet rs = stmt.executeQuery();
                
                while (rs.next()) {
                    Product product = new Product(
                        rs.getInt("product_id"),
                        rs.getString("name"),
                        rs.getDouble("price"),
                        rs.getString("description"),
                        rs.getInt("stockQuantity")
                    );
                    orderDetails.put(product, rs.getInt("quantity"));
                }
            }
            
            if (!orderDetails.isEmpty()) {
                orders.add(orderDetails);
            }
        }
        
        return orders;
    }

    @Override
    public Order getOrderById(int orderId) throws SQLException, OrderNotFoundException {
        String query = "SELECT * FROM orders WHERE order_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Order(
                    rs.getInt("order_id"),
                    rs.getInt("customer_id"),
                    rs.getTimestamp("order_date"),
                    rs.getDouble("total_price"),
                    rs.getString("shipping_address")
                );
            } else {
                throw new OrderNotFoundException("Order with ID " + orderId + " not found.");
            }
        }
    }

    @Override
    public List<OrderItem> getOrderItemsByOrderId(int orderId) throws SQLException, OrderNotFoundException {
        if (!orderExists(orderId)) {
            throw new OrderNotFoundException("Order with ID " + orderId + " not found.");
        }
        
        List<OrderItem> items = new ArrayList<>();
        String query = "SELECT * FROM order_items WHERE order_id = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                OrderItem item = new OrderItem(
                    rs.getInt("order_item_id"),
                    rs.getInt("order_id"),
                    rs.getInt("product_id"),
                    rs.getInt("quantity")
                );
                items.add(item);
            }
        }
        
        return items;
    }

    @Override
    public boolean cancelOrder(int orderId) throws SQLException, OrderNotFoundException {
        if (!orderExists(orderId)) {
            throw new OrderNotFoundException("Order with ID " + orderId + " not found.");
        }
        
        connection.setAutoCommit(false);
        
        try {
            // 1. Get order items to restore stock
            List<OrderItem> items = getOrderItemsByOrderId(orderId);
            
            // 2. Restore product stock
            String restoreStockQuery = "UPDATE products SET stockQuantity = stockQuantity + ? WHERE product_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(restoreStockQuery)) {
                for (OrderItem item : items) {
                    stmt.setInt(1, item.getQuantity());
                    stmt.setInt(2, item.getProductId());
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
            
            // 3. Delete order items
            String deleteItemsQuery = "DELETE FROM order_items WHERE order_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(deleteItemsQuery)) {
                stmt.setInt(1, orderId);
                stmt.executeUpdate();
            }
            
            // 4. Delete the order
            String deleteOrderQuery = "DELETE FROM orders WHERE order_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(deleteOrderQuery)) {
                stmt.setInt(1, orderId);
                int result = stmt.executeUpdate();
                
                if (result > 0) {
                    connection.commit();
                    return true;
                } else {
                    connection.rollback();
                    return false;
                }
            }
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    // Helper methods
    private boolean customerExists(int customerId) throws SQLException {
        String query = "SELECT 1 FROM customers WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
    
    private boolean productExists(int productId) throws SQLException {
        String query = "SELECT 1 FROM products WHERE product_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
    
    private boolean orderExists(int orderId) throws SQLException {
        String query = "SELECT 1 FROM orders WHERE order_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
    
    private int getProductStock(int productId) throws SQLException {
        String query = "SELECT stockQuantity FROM products WHERE product_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getInt("stockQuantity") : 0;
        }
    }
}