package org.example;

import entity.Product;
import entity.Cart;
import entity.Order;
import exception.CustomerNotFoundException;
import exception.ProductNotFoundException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class EcommerceTests {

    @Test
    public void testProductCreation() {
        Product product = new Product(1, "Laptop", 50000.0, "High-end gaming laptop", 10);
        Assertions.assertEquals("Laptop", product.getName());
        Assertions.assertEquals(50000.0, product.getPrice());
        Assertions.assertEquals(10, product.getStockQuantity());
    }

    @Test
    public void testAddProductToCart() {
        Cart cart = new Cart(101, 1, 1001, 2); // cartId, customerId, productId, quantity
        Assertions.assertEquals(101, cart.getCartId());
        Assertions.assertEquals(1, cart.getCustomerId());
        Assertions.assertEquals(1001, cart.getProductId());
        Assertions.assertEquals(2, cart.getQuantity());
    }

    @Test
    public void testOrderCreation() {
        Date orderDate = new Date();
        Order order = new Order(5001, 1, orderDate, 999.99, "Pune");
        Assertions.assertEquals(5001, order.getOrderId());
        Assertions.assertEquals(1, order.getCustomerId());
        Assertions.assertEquals(999.99, order.getTotalPrice());
        Assertions.assertEquals("Pune", order.getShippingAddress());
    }

    @Test
    public void testCustomerNotFoundException() {
        Assertions.assertThrows(CustomerNotFoundException.class, () -> {
            throw new CustomerNotFoundException("Customer not found");
        });
    }

    @Test
    public void testProductNotFoundException() {
        Assertions.assertThrows(ProductNotFoundException.class, () -> {
            throw new ProductNotFoundException("Product not found");
        });
    }
}