package dao;

import entity.Policy;
import exception.PolicyNotFoundException;

import java.util.List;

public interface IPolicyService {
    boolean createPolicy(Policy policy) throws Exception;
    Policy getPolicy(int policyId) throws PolicyNotFoundException, Exception;
    List<Policy> getAllPolicies() throws Exception;
    boolean updatePolicy(Policy policy) throws Exception;
    boolean deletePolicy(int policyId) throws PolicyNotFoundException, Exception;
}