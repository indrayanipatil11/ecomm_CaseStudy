package dao;

import entity.Policy;
import exception.PolicyNotFoundException;
import util.DBPropertyUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyServiceImpl implements IPolicyService {
    private Connection conn;

    public PolicyServiceImpl() throws SQLException {
        conn = DBPropertyUtil.getConnection();
        if (conn == null) {
            throw new SQLException("Failed to establish database connection.");
        }
    }

    @Override
    public boolean createPolicy(Policy policy) throws SQLException {
        String query = "INSERT INTO Policy (policyId, policyName, coverageAmount, premium) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, policy.getPolicyId());
            ps.setString(2, policy.getPolicyName());
            ps.setDouble(3, policy.getCoverageAmount());
            ps.setDouble(4, policy.getPremium());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public Policy getPolicy(int policyId) throws SQLException, PolicyNotFoundException {
        String query = "SELECT * FROM Policy WHERE policyId = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, policyId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Policy(rs.getInt("policyId"), rs.getString("policyName"),
                        rs.getDouble("coverageAmount"), rs.getDouble("premium"));
            } else {
                throw new PolicyNotFoundException("Policy with ID " + policyId + " not found.");
            }
        }
    }

    @Override
    public List<Policy> getAllPolicies() throws SQLException {
        List<Policy> list = new ArrayList<>();
        String query = "SELECT * FROM Policy";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(query)) {
            while (rs.next()) {
                list.add(new Policy(rs.getInt("policyId"), rs.getString("policyName"),
                        rs.getDouble("coverageAmount"), rs.getDouble("premium")));
            }
        }
        return list;
    }

    @Override
    public boolean updatePolicy(Policy policy) throws SQLException {
        String query = "UPDATE Policy SET policyName = ?, coverageAmount = ?, premium = ? WHERE policyId = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, policy.getPolicyName());
            ps.setDouble(2, policy.getCoverageAmount());
            ps.setDouble(3, policy.getPremium());
            ps.setInt(4, policy.getPolicyId());
            int rows = ps.executeUpdate() ;
            return rows>0;
        }
    }

    @Override
    public boolean deletePolicy(int policyId) throws SQLException, PolicyNotFoundException {
        // Check existence before deleting
        getPolicy(policyId);
        String query = "Delete from policy WHERE policyId = ?;";

        try (PreparedStatement ps = conn.prepareStatement(query);){
            ps.setInt(1, policyId);
            return ps.executeUpdate() > 0;

        }
    }
}