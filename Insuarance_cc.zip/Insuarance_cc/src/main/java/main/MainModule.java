package main;

import dao.PolicyServiceImpl;
import entity.Policy;
import exception.PolicyNotFoundException;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            PolicyServiceImpl service;
            try {
                service = new PolicyServiceImpl();
            } catch (SQLException e) {
                System.out.println("Database connection failed: " + e.getMessage());
                return;
            }

            boolean exit = false;

            while (!exit) {
                System.out.println("\n--- Insurance Policy Menu ---");
                System.out.println("1. Create Policy");
                System.out.println("2. View Policy");
                System.out.println("3. View All Policies");
                System.out.println("4. Update Policy");
                System.out.println("5. Delete Policy");
                System.out.println("6. Exit");
                System.out.print("Choose an option: ");
                int choice = sc.nextInt();

                try {
                    switch (choice) {
                        case 1:
                            System.out.print("Enter Policy ID");
                            int id = sc.nextInt();
                            System.out.print("Enter Name");
                            String name = sc.next();
                            System.out.print("Enter Coverage");
                            double coverage = sc.nextDouble();
                            System.out.print("Enter Premium");
                            double premium = sc.nextDouble();

                            Policy p1 = new Policy(id,name,coverage,premium);
                            if (service.createPolicy(p1))
                                System.out.println("Policy created successfully.");
                            else
                                System.out.println("Policy creation failed.");
                            break;

                        case 2:
                            System.out.print("Enter Policy ID: ");
                            Policy p2 = service.getPolicy(sc.nextInt());
                            System.out.println("Policy Details: " + p2);
                            break;

                        case 3:
                            List<Policy> list = service.getAllPolicies();
                            System.out.println("All Policies:");
                            list.forEach(System.out::println);
                            break;

                        case 4:
                            System.out.print("Enter Policy ID, New Name, New Coverage, New Premium: ");
                            Policy p3 = new Policy(sc.nextInt(), sc.next(), sc.nextDouble(), sc.nextDouble());
                            if (service.updatePolicy(p3))
                                System.out.println("Policy updated.");
                            else
                                System.out.println("Update failed.");
                            break;

                        case 5:
                            System.out.print("Enter Policy ID to delete: ");
                            if (service.deletePolicy(sc.nextInt()))
                                System.out.println("Policy deleted.");
                            else
                                System.out.println("Deletion failed.");
                            break;

                        case 6:
                            exit = true;
                            System.out.println("Exiting program.");
                            break;

                        default:
                            System.out.println("Invalid option. Try again.");
                    }
                } catch (PolicyNotFoundException e) {
                    System.out.println("Error: " + e.getMessage());
                } catch (SQLException e) {
                    System.out.println("SQL Error: " + e.getMessage());
                } catch (Exception e) {
                    System.out.println("Unexpected Error: " + e.getMessage());
                }
            }
        }
    }
}