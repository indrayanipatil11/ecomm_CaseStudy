package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBPropertyUtil {

    public static String getPropertyString() {
        String hostname = "localhost";
        String port = "3306";
        String dbname = "Insurance_cc";
        String username = "root";
        String password = "Hexaware@12345";

        return "jdbc:mysql://" + hostname + ":" + port + "/" + dbname +
                "?user=" + username + "&password=" + password;
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Add this line to register driver
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        String url = getPropertyString();
        return DriverManager.getConnection(url);
    }
}